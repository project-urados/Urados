#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "${1:-.}" && pwd)
SELINUX="$ROOT/selinux"
TMP=$(mktemp -d "/run/urados-build.XXXXXX")

cleanup() {
    rm -rf "$TMP"
}
trap cleanup EXIT HUP INT TERM

[ "$(id -u)" -eq 0 ] || {
    echo "error: run as root" >&2
    exit 1
}

command -v checkmodule >/dev/null 2>&1 ||
    { echo "error: checkmodule is missing" >&2; exit 1; }

command -v semodule_package >/dev/null 2>&1 ||
    { echo "error: semodule_package is missing" >&2; exit 1; }

command -v semodule >/dev/null 2>&1 ||
    { echo "error: semodule is missing" >&2; exit 1; }

# Convert the Urados policy wrapper to native module syntax.
sed '1s/^policy_module(urados, *1\.0) */module urados 1.0;\n/' \
    "$SELINUX/urados.te" > "$TMP/urados.te"

echo "Compiling Urados policy module..."
checkmodule -M -m \
    -o "$TMP/urados.mod" \
    "$TMP/urados.te"

echo "Creating Urados policy package..."
semodule_package \
    -o "$TMP/urados.pp" \
    -m "$TMP/urados.mod" \
    -f "$SELINUX/urados.fc"

echo "Installing Urados policy module..."
semodule -i "$TMP/urados.pp"

echo "Urados SELinux policy installed."